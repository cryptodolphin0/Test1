Documentation is moved to [separate repository](https://github.com/PurpleI2P/i2pd_docs_en.git)

[View docs online](https://i2pd.readthedocs.io/en/latest/)
